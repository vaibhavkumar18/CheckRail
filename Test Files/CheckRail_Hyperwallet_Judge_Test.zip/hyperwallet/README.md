# CheckRail Hyperwallet Sandbox Test Package

Purpose: upload this source ZIP to a Hyperwallet expansion project in CheckRail to demonstrate Integration Intelligence, Country Intelligence, Hyperwallet Sandbox credential verification, Payment Disbursement capability verification, and AI Gap Analysis.

Steps:
1. Create/open a Hyperwallet expansion project and select its target country.
2. Upload this ZIP in Integration Intelligence and review/confirm the profile.
3. Add Hyperwallet Sandbox API username, password, and program token in CheckRail's credential form.
4. Run credential verification and Payment Disbursement capability verification.
5. Complete Country Intelligence for the selected target country.
6. Run AI Gap Analysis and review Expansion Readiness.

Files: src/hyperwallet.config.js and src/hyperwallet.js. `.env.example` contains placeholders only.

Use Sandbox credentials only. Never publish passwords or program tokens in GitHub or public Devpost fields. Country-specific recipient and bank fields vary by target country and Sandbox program; pass the matching fixture values. This sample does not claim production approval or universal country support.
