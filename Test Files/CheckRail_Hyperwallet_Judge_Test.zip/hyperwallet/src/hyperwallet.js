import { hyperwalletConfig, assertHyperwalletConfig } from "./hyperwallet.config.js";

async function request(path, method = "GET", body) {
  assertHyperwalletConfig();
  const auth = Buffer.from(`${hyperwalletConfig.username}:${hyperwalletConfig.password}`).toString("base64");
  const response = await fetch(`${hyperwalletConfig.baseUrl}/rest/v4${path}`, {
    method,
    headers: { Authorization: `Basic ${auth}`, Accept: "application/json", ...(body ? { "Content-Type": "application/json" } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.message || `Hyperwallet API failed: ${response.status}`);
    error.status = response.status;
    error.details = data;
    throw error;
  }
  return { status: response.status, data };
}

export async function createRecipient(recipient) {
  return request("/users", "POST", { ...recipient, programToken: hyperwalletConfig.programToken });
}

export async function getTransferMethodConfigurations({ country, currency, type = "BANK_ACCOUNT" }) {
  const query = new URLSearchParams({ country: country.toUpperCase(), currency: currency.toUpperCase(), type });
  return request(`/transfer-method-configurations?${query}`);
}

export async function createBankAccount(userToken, bankAccount) {
  if (!userToken) throw new Error("userToken is required");
  return request(`/users/${encodeURIComponent(userToken)}/bank-accounts`, "POST", bankAccount);
}

export async function getBankAccount(userToken, bankAccountToken) {
  return request(`/users/${encodeURIComponent(userToken)}/bank-accounts/${encodeURIComponent(bankAccountToken)}`);
}

export async function createPayment(payment) {
  return request("/payments", "POST", { ...payment, programToken: hyperwalletConfig.programToken });
}

export async function getPayment(paymentToken) {
  return request(`/payments/${encodeURIComponent(paymentToken)}`);
}
