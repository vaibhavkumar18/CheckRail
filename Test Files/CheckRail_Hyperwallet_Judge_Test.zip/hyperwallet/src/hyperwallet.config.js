export const hyperwalletConfig = {
  baseUrl: (process.env.HYPERWALLET_BASE_URL || "https://api.sandbox.hyperwallet.com").replace(/\/+$/, ""),
  username: process.env.HYPERWALLET_USERNAME,
  password: process.env.HYPERWALLET_PASSWORD,
  programToken: process.env.HYPERWALLET_PROGRAM_TOKEN,
};

export function assertHyperwalletConfig() {
  const missing = ["username", "password", "programToken"].filter((key) => !hyperwalletConfig[key]);
  if (missing.length) throw new Error(`Missing Hyperwallet config: ${missing.join(", ")}`);
}
