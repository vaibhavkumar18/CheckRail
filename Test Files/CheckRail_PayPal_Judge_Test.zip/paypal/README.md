# CheckRail PayPal Sandbox Test Package

Purpose: upload this source ZIP to a PayPal project in CheckRail to demonstrate Integration Intelligence, PayPal Sandbox credential verification, Payment Processing capability verification, and AI Gap Analysis.

Steps:
1. Create/open a PayPal project in CheckRail.
2. Upload this ZIP in Integration Intelligence and review/confirm the profile.
3. Add PayPal Sandbox Client ID and Client Secret in CheckRail's credential form.
4. Run credential verification and Payment Processing capability verification.
5. Run AI Gap Analysis.

Files: src/paypal.config.js and src/paypal.js. `.env.example` contains placeholders only.

Use Sandbox credentials only. Never publish secrets in GitHub or public Devpost fields. This example demonstrates PayPal Orders v2 create/capture flows; it does not implement seller payouts or production compliance.
