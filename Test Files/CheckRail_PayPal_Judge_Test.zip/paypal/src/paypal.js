import { paypalConfig, assertPayPalConfig } from "./paypal.config.js";

async function accessToken() {
  assertPayPalConfig();
  const basic = Buffer.from(`${paypalConfig.clientId}:${paypalConfig.clientSecret}`).toString("base64");
  const response = await fetch(`${paypalConfig.baseUrl}/v1/oauth2/token`, {
    method: "POST",
    headers: { Authorization: `Basic ${basic}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=client_credentials",
  });
  const data = await response.json();
  if (!response.ok || !data.access_token) throw new Error(data.error_description || `OAuth failed: ${response.status}`);
  return data.access_token;
}

async function paypalRequest(path, method = "GET", body) {
  const token = await accessToken();
  const response = await fetch(`${paypalConfig.baseUrl}${path}`, {
    method,
    headers: { Authorization: `Bearer ${token}`, ...(body ? { "Content-Type": "application/json" } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.message || `PayPal API failed: ${response.status}`);
    error.status = response.status;
    error.details = data;
    throw error;
  }
  return { status: response.status, data };
}

export async function createOrder({ amount, currency = "USD", referenceId }) {
  return paypalRequest("/v2/checkout/orders", "POST", {
    intent: "CAPTURE",
    purchase_units: [{
      reference_id: referenceId || `checkrail-${Date.now()}`,
      amount: { currency_code: currency, value: Number(amount).toFixed(2) },
    }],
    application_context: { user_action: "PAY_NOW", shipping_preference: "NO_SHIPPING" },
  });
}

export async function captureOrder(orderId) {
  if (!orderId) throw new Error("orderId is required");
  return paypalRequest(`/v2/checkout/orders/${encodeURIComponent(orderId)}/capture`, "POST");
}
