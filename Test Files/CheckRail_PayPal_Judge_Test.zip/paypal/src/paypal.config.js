export const paypalConfig = {
  baseUrl: (process.env.PAYPAL_BASE_URL || "https://api-m.sandbox.paypal.com").replace(/\/+$/, ""),
  clientId: process.env.PAYPAL_CLIENT_ID,
  clientSecret: process.env.PAYPAL_CLIENT_SECRET,
  webhookId: process.env.PAYPAL_WEBHOOK_ID,
};

export function assertPayPalConfig() {
  const missing = ["clientId", "clientSecret"].filter((key) => !paypalConfig[key]);
  if (missing.length) throw new Error(`Missing PayPal config: ${missing.join(", ")}`);
}
