import config from "../../../config/config.js";
import { buildGapAnalysisMessages } from "./gapAnalysis.prompt.js";
import { parseGapAnalysisResponse } from "./gapAnalysis.schema.js";

const OPENROUTER_URL =
  "https://openrouter.ai/api/v1/chat/completions";

export const generateGapAnalysisWithOpenRouter = async ({
  context,
  validEvidenceRefs,
}) => {
  const enabled =
    String(config.AI_ENABLED).toLowerCase() === "true";

  if (!enabled) {
    const error = new Error(
      "AI Gap Analysis is disabled by AI_ENABLED configuration.",
    );

    error.code = "AI_DISABLED";
    error.statusCode = 503;
    throw error;
  }

  const provider = String(config.AI_PROVIDER || "")
    .trim()
    .toLowerCase();

  if (provider !== "openrouter") {
    const error = new Error(
      `Unsupported AI_PROVIDER: ${provider || "not configured"}.`,
    );

    error.code = "UNSUPPORTED_AI_PROVIDER";
    error.statusCode = 503;
    throw error;
  }

  const apiKey = config.OPENROUTER_API_KEY?.trim();

  if (!apiKey || apiKey.startsWith("Bearer ")) {
    const error = new Error(
      "OPENROUTER_API_KEY is missing or incorrectly configured.",
    );

    error.code = "OPENROUTER_CONFIGURATION_ERROR";
    error.statusCode = 503;
    throw error;
  }

  const model =
    config.OPENROUTER_MODEL || "openai/gpt-oss-120b";

  const timeoutMs = Number(config.AI_TIMEOUT_MS || 30000);

  if (!Number.isFinite(timeoutMs) || timeoutMs < 1000) {
    throw new Error(
      "AI_TIMEOUT_MS must be a valid number of at least 1000.",
    );
  }

  const controller = new AbortController();

  const timeout = setTimeout(
    () => controller.abort(),
    timeoutMs,
  );

  try {
    const headers = {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    };

    if (process.env.OPENROUTER_HTTP_REFERER) {
      headers["HTTP-Referer"] =
        process.env.OPENROUTER_HTTP_REFERER;
    }

    if (process.env.OPENROUTER_APP_NAME) {
      headers["X-Title"] =
        process.env.OPENROUTER_APP_NAME;
    }

    const messages = buildGapAnalysisMessages(
      context,
      validEvidenceRefs,
    );

    const response = await fetch(OPENROUTER_URL, {
      method: "POST",
      headers,
      signal: controller.signal,

      body: JSON.stringify({
        model,
        messages,
        temperature: 0,
        max_tokens: 7000,
        response_format: {
          type: "json_object",
        },
      }),
    });

    const body = await response.json().catch(() => null);

    if (!response.ok) {
      const error = new Error(
        body?.error?.message ||
          `OpenRouter request failed with HTTP ${response.status}.`,
      );

      error.code = "OPENROUTER_REQUEST_FAILED";
      error.statusCode = response.status;

      throw error;
    }

    const content =
      body?.choices?.[0]?.message?.content;

    if (
      typeof content !== "string" ||
      !content.trim()
    ) {
      const error = new Error(
        "OpenRouter returned an empty Gap Analysis response.",
      );

      error.code = "AI_EMPTY_RESPONSE";
      throw error;
    }

    let parsedData;

    try {
      parsedData = parseGapAnalysisResponse(
        content,
        validEvidenceRefs,
      );
    } catch (error) {
      if (error.code === "AI_INVALID_EVIDENCE_REFERENCE") {
        console.error(
          "AI returned invalid evidence references:",
          error.invalidEvidenceRefs || [],
        );
      }

      throw error;
    }

    return {
      data: parsedData,
      provider: "OPENROUTER",
      model: body?.model || model,
      requestId: body?.id || null,
      usage: body?.usage || null,
    };
  } catch (error) {
    if (error.name === "AbortError") {
      const timeoutError = new Error(
        "OpenRouter Gap Analysis request timed out.",
      );

      timeoutError.code = "AI_TIMEOUT";
      timeoutError.statusCode = 504;

      throw timeoutError;
    }

    throw error;
  } finally {
    clearTimeout(timeout);
  }
};