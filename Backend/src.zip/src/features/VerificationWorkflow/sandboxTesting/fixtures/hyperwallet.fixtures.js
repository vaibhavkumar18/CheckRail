/**
 * Hyperwallet Sandbox fixtures keyed by the project's target country.
 *
 * IMPORTANT:
 * This splits the currencies to enable a cross-border sandbox transaction.
 * The bank account is registered in INR, while the payment pool pulls from USD.
 */

const normalizeCountry = (value) =>
  String(value ?? "")
    .trim()
    .toUpperCase();

const clone = (value) => JSON.parse(JSON.stringify(value));

const COUNTRY_FIXTURES = Object.freeze({
  IN: Object.freeze({
    recipient: Object.freeze({
      profileType: "INDIVIDUAL",
      firstName: "CorridorGate",
      lastName: "SandboxPayee",
      dateOfBirth: "1990-01-15",
      email: "corridorgate-sandbox@example.com",
      addressLine1: "100 Sandbox Test Road",
      city: "Bengaluru",
      stateProvince: "Karnataka",
      country: "IN",
      postalCode: "560001",
    }),

    bankAccount: Object.freeze({
      profileType: "INDIVIDUAL",
      country: "IN",
      transferMethodCountry: "IN",
      
      // FIX 1: Explicitly set the destination bank account currency to INR
      transferMethodCurrency: "INR",

      branchId: "HDFC0000001",
      ifscCode: "HDFC0000001",
      bankAccountId: "50100234567890",
      accountNumber: "50100234567890",
      bankAccountPurpose: "SAVINGS",
      accountType: "SAVINGS",
      firstName: "CorridorGate",
      lastName: "SandboxPayee",
      addressLine1: "100 Sandbox Test Road",
      city: "Bengaluru",
      stateProvince: "Karnataka",
      postalCode: "560001",
    }),

    payment: Object.freeze({
      amount: "1.00",
      
      // FIX 2: Explicitly pull payment liquidity from your $1,000,000.00 USD pool
      currency: "USD",
      
      purpose: "PAYROLL",
      memo: "CorridorGate Sandbox verification",
      notes: "Synthetic Sandbox test payment only",
    }),
  }),
});

/**
 * Resolve a fixture for exactly the target country selected on the project.
 */
export const createHyperwalletSandboxFixture = ({ targetCountry }) => {
  const country = normalizeCountry(targetCountry);

  if (!/^[A-Z]{2}$/.test(country)) {
    throw new Error("A valid two-letter project target country is required.");
  }

  const countryFixture = COUNTRY_FIXTURES[country];
  if (!countryFixture) {
    throw new Error(`No approved fixture configured for target country ${country}.`);
  }

  const recipient = clone(countryFixture.recipient);
  const bankAccount = clone(countryFixture.bankAccount);
  const payment = clone(countryFixture.payment);

  if (country === "IN") {
    // Generate fresh high-entropy account sequences to bypass 400 duplication safeguards
    const timestampSegment = Date.now().toString().slice(-6);
    const randomizedSegment = Math.floor(100 + Math.random() * 900).toString();
    const freshAccountNumber = `50100${timestampSegment}${randomizedSegment}`;

    bankAccount.bankAccountId = freshAccountNumber;
    bankAccount.accountNumber = freshAccountNumber;
  }

  if (normalizeCountry(recipient.country) !== country) {
    throw new Error("Hyperwallet fixture does not match the project's target country.");
  }

  if (normalizeCountry(bankAccount.transferMethodCountry) !== country) {
    throw new Error("Hyperwallet fixture bank account does not match the project's target country.");
  }

  return Object.freeze({
    country,
    recipient: Object.freeze(recipient),
    bankAccount: Object.freeze(bankAccount),
    payment: Object.freeze(payment),
  });
};
