import config from "../../../config/config.js";
import { buildCountryResearchMessages } from "./countryResearch.prompt.js";
import { parseCountryResearchResponse } from "../extraction/countryResearch.schema.js";

const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";

const extractTextContent = (content) => {
  if (typeof content === "string") {
    return content.trim();
  }

  if (Array.isArray(content)) {
    return content
      .map((item) => {
        if (typeof item === "string") return item;
        if (typeof item?.text === "string") return item.text;
        return "";
      })
      .filter(Boolean)
      .join("\n")
      .trim();
  }

  return "";
};

export const interpretCountrySources = async ({
  countryName,
  countryCode,
  sources,
}) => {
  const apiKey = config.OPENROUTER_API_KEY?.trim();
  const model = config.OPENROUTER_MODEL;
  const timeoutMs = Number(config.AI_TIMEOUT_MS || 45000);

  if (!apiKey) {
    throw new Error("OPENROUTER_API_KEY is not configured.");
  }

  if (apiKey.startsWith("Bearer ")) {
    throw new Error(
      "OPENROUTER_API_KEY must contain only the API key, without the Bearer prefix.",
    );
  }

  if (!model) {
    throw new Error("OPENROUTER_MODEL is not configured.");
  }

  if (!Number.isFinite(timeoutMs) || timeoutMs < 1000) {
    throw new Error("AI_TIMEOUT_MS must be at least 1000.");
  }

  if (!Array.isArray(sources) || sources.length < 2) {
    throw new Error("Insufficient source evidence for country research.");
  }

  console.log("[Country Intelligence: OpenRouter]", {
    countryCode,
    countryName,
    model,
    sourceCount: sources.length,
    timeoutMs,
  });

  const response = await fetch(OPENROUTER_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      ...(process.env.OPENROUTER_HTTP_REFERER
        ? { "HTTP-Referer": process.env.OPENROUTER_HTTP_REFERER }
        : {}),
      ...(process.env.OPENROUTER_APP_NAME
        ? { "X-Title": process.env.OPENROUTER_APP_NAME }
        : {}),
    },
    body: JSON.stringify({
      model,
      messages: buildCountryResearchMessages({
        countryName,
        countryCode,
        sources,
      }),
      temperature: 0.1,
      max_tokens: 7000,
      response_format: { type: "json_object" },
    }),
    signal: AbortSignal.timeout(timeoutMs),
  });

  const rawResponse = await response.text();

  let body = null;

  try {
    body = rawResponse ? JSON.parse(rawResponse) : null;
  } catch {
    console.error("[OpenRouter: Non-JSON response]", {
      httpStatus: response.status,
      statusText: response.statusText,
      contentType: response.headers.get("content-type"),
      responseBody: rawResponse.slice(0, 5000),
    });

    throw new Error(
      `OpenRouter returned a non-JSON response. HTTP ${response.status}.`,
    );
  }

  console.log("[OpenRouter: Response diagnostics]", {
    httpStatus: response.status,
    statusText: response.statusText,
    contentType: response.headers.get("content-type"),
    bodyKeys: body ? Object.keys(body) : [],
    hasChoices: Array.isArray(body?.choices),
    choicesCount: body?.choices?.length ?? 0,
    error: body?.error ?? null,
    responsePreview: rawResponse.slice(0, 2000),
  });

  if (!response.ok) {
    const error = new Error(
      body?.error?.message ||
        `OpenRouter country research failed with HTTP ${response.status}.`,
    );

    error.statusCode = response.status;
    error.retryable = response.status === 429 || response.status >= 500;

    throw error;
  }

  const choice = body?.choices?.[0];
  const message = choice?.message;
  const content = extractTextContent(message?.content);

  if (!content) {
    console.error("[Country Intelligence: Empty OpenRouter response]", {
      requestId: body?.id || null,
      model: body?.model || model,
      finishReason: choice?.finish_reason || null,
      messageKeys: message ? Object.keys(message) : [],
      refusal: message?.refusal || null,
      hasReasoning: Boolean(message?.reasoning),
      usage: body?.usage || null,
      provider: body?.provider || null,
    });

    const error = new Error(
      `OpenRouter returned no final text. Finish reason: ${
        choice?.finish_reason || "unknown"
      }. Request ID: ${body?.id || "unavailable"}.`,
    );

    error.code = "OPENROUTER_EMPTY_CONTENT";
    throw error;
  }

  let parsedData;

  try {
    parsedData = parseCountryResearchResponse(content, sources);
  } catch (parseError) {
  console.error("[Country Intelligence: Invalid AI response]", {
    requestId: body?.id || null,
    model: body?.model || model,
    finishReason: choice?.finish_reason || null,
    contentLength: content.length,
    parseError: parseError.message,
    validationIssues: parseError.details || [],
    invalidSourceIds: parseError.invalidSourceIds || [],
  });

  throw new Error(
    `Country Intelligence validation failed: ${parseError.message}`
  );
}

  return {
    data: parsedData,
    model: body?.model || model,
    requestId: body?.id || null,
    usage: body?.usage || null,
  };
};
