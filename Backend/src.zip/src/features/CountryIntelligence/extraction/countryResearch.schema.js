
import { z } from "zod";

const CountrySchema = z
  .object({
    code: z.string().regex(/^[A-Z]{2}$/),
    name: z.string().min(1).max(120),
  })
  .strict();

const OverviewSchema = z
  .object({
    summary: z.string().min(20).max(1800),

    officialCurrency: z
      .array(z.string().min(1).max(80))
      .max(8),

    currencyAndSettlementNotes: z
      .array(z.string().min(1).max(500))
      .max(8),

    paymentMethods: z
      .array(z.string().min(1).max(160))
      .max(15),

    collectionNotes: z
      .array(z.string().min(1).max(500))
      .max(8),

    disbursementNotes: z
      .array(z.string().min(1).max(500))
      .max(8),

    researchLimitations: z
      .array(z.string().min(1).max(500))
      .max(12),
  })
  .strict();

const RequirementSchema = z
  .object({
    category: z.enum([
      "PAYMENT_ECOSYSTEM",
      "COLLECTIONS",
      "DISBURSEMENTS",
      "CURRENCY_AND_SETTLEMENT",
      "BUSINESS_ELIGIBILITY",
      "REGULATORY",
      "KYC_AML",
      "BANKING_AND_OPERATIONS",
    ]),

    title: z.string().min(4).max(240),

    description: z.string().min(20).max(1800),

    applicability: z.enum([
      "MARKETPLACE",
      "MERCHANT",
      "CUSTOMER",
      "PAYMENT_PROVIDER",
      "GENERAL",
    ]),

    evidenceStatus: z.enum([
      "CONFIRMED",
      "UNVERIFIED",
      "CONFLICTING",
    ]),

    confidence: z.enum([
      "HIGH",
      "MEDIUM",
      "LOW",
      "UNKNOWN",
    ]),

    confidenceScore: z.number().min(0).max(1).nullable(),

    evidenceIds: z
      .array(z.string().regex(/^SRC_\d+$/))
      .min(1)
      .max(8),

    limitations: z
      .array(z.string().max(500))
      .max(8),
  })
  .strict();

export const CountryResearchResponseSchema = z
  .object({
    country: CountrySchema,

    overview: OverviewSchema,

    requirements: z
      .array(RequirementSchema)
      .max(60),
  })
  .strict();

export const parseCountryResearchResponse = (
  rawContent,
  sources,
) => {
  let parsed;

  try {
    parsed = JSON.parse(rawContent);
  } catch (cause) {
    const error = new Error(
      "Country research AI returned invalid JSON.",
    );

    error.code = "COUNTRY_AI_INVALID_JSON";
    error.cause = cause;

    throw error;
  }

  const validated =
    CountryResearchResponseSchema.safeParse(parsed);

  if (!validated.success) {
    const error = new Error(
      "Country research AI response failed schema validation.",
    );

    error.code = "COUNTRY_AI_SCHEMA_INVALID";

    error.details = validated.error.issues.map((issue) => ({
      path: issue.path.join("."),
      code: issue.code,
      message: issue.message,
      received: issue.received,
      expected: issue.expected,
    }));

    throw error;
  }

  const validIds = new Set(
    sources.map((source) => source.sourceKey),
  );

  const invalidIds = [];

  for (const requirement of validated.data.requirements) {
    for (const id of requirement.evidenceIds) {
      if (!validIds.has(id)) {
        invalidIds.push(id);
      }
    }
  }

  if (invalidIds.length > 0) {
    const error = new Error(
      "Country research AI referenced source IDs that were not retrieved.",
    );

    error.code = "COUNTRY_AI_INVALID_SOURCE_REFERENCE";

    error.invalidSourceIds = [
      ...new Set(invalidIds),
    ];

    throw error;
  }

  return validated.data;
};
